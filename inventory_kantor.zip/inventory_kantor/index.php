<?php
include 'db.php';

// Proses Tambah Barang
if (isset($_POST['tambah'])) {
    $kode_barang = $_POST['kode_barang'];
    $nama_barang = $_POST['nama_barang'];
    $jumlah      = $_POST['jumlah'];
    $lokasi      = $_POST['lokasi'];
    $kondisi     = $_POST['kondisi'];

    $conn->query("INSERT INTO barang (kode_barang, nama_barang, jumlah, lokasi, kondisi) 
                  VALUES ('$kode_barang', '$nama_barang', '$jumlah', '$lokasi', '$kondisi')");
    header("Location: index.php");
}
// Proses Edit Barang
if (isset($_POST['edit'])) {
    $id          = $_POST['id'];
    $kode_barang = $_POST['kode_barang'];
    $nama_barang = $_POST['nama_barang'];
    $jumlah      = $_POST['jumlah'];
    $lokasi      = $_POST['lokasi'];
    $kondisi     = $_POST['kondisi'];

    $conn->query("UPDATE barang SET 
                    kode_barang = '$kode_barang', 
                    nama_barang = '$nama_barang', 
                    jumlah      = '$jumlah', 
                    lokasi      = '$lokasi', 
                    kondisi     = '$kondisi'
                  WHERE id = $id");

    header("Location: index.php");
}

// Ambil data untuk form edit jika ada parameter edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id_edit   = $_GET['edit'];
    $result    = $conn->query("SELECT * FROM barang WHERE id = $id_edit");
    $edit_data = $result->fetch_assoc();
}

// Proses Hapus Barang
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM barang WHERE id = $id");
    header("Location: index.php");
}

// Fitur SORT
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'id';
$order   = isset($_GET['order']) ? $_GET['order'] : 'DESC';

// Validasi kolom yang bisa disort
$valid_columns = ['kode_barang', 'nama_barang', 'jumlah', 'lokasi', 'kondisi', 'id'];
if (!in_array($sort_by, $valid_columns)) {
    $sort_by = 'id';
}
$order = ($order == 'ASC') ? 'ASC' : 'DESC';

// Ambil data barang dengan ORDER BY
$data_barang = $conn->query("SELECT * FROM barang ORDER BY $sort_by $order");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory Kantor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Reset & base */
        body {
            background: linear-gradient(135deg, #c3dfff, #e6f0ff);
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #0a2140;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #4a90e2, #2a65c7);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 30px 20px;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .sidebar h3 {
            margin-bottom: 40px;
            font-weight: 700;
            font-size: 1.8rem;
            letter-spacing: 1.2px;
            user-select: none;
        }
        .sidebar a {
            width: 100%;
            display: block;
            color: #dbe9ff;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: 600;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.3s ease, color 0.3s ease;
            box-shadow: inset 0 0 0 0 transparent;
        }
        .sidebar a:hover {
            background-color: #3b7ddd;
            color: #fff;
            box-shadow: inset 5px 0 10px rgba(255,255,255,0.3);
        }

        /* Main content */
        .main-content {
            margin-left: 260px;
            padding: 40px 50px;
            min-height: 100vh;
        }
        .main-content h2 {
            color: #1a3c72;
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 5px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
        }
        .main-content h5 {
            color: #345c99;
            font-weight: 500;
            margin-bottom: 40px;
            letter-spacing: 0.8px;
        }

        /* Table styles */
        .table-pink thead {
            background-color: #7db9e8; /* soft blue */
            color: #08244f;
            font-weight: 600;
            font-size: 1rem;
        }
        .table-pink tbody tr:nth-child(even) {
            background-color: #d9e9ff;
        }
        .table-pink tbody tr:nth-child(odd) {
            background-color: #f1f9ff;
        }
        .table-pink tbody tr:hover {
            background-color: #a9c9ff;
            color: #08244f;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .table-pink td, .table-pink th {
            vertical-align: middle;
            padding: 14px 18px;
            border-top: none !important;
            border-bottom: 1px solid #c5d9f1;
        }

        /* Kotak warna tiap kolom tbody */
        .table-pink tbody td {
            border-radius: 8px;
            padding: 14px 18px;
            margin: 4px 2px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        /* Kolom ID */
        .table-pink tbody td:nth-child(1) {
            background-color: #d0e7ff;  /* biru muda */
            border: 1px solid #8ab6ff;
        }
        /* Kolom Nama Barang */
        .table-pink tbody td:nth-child(2) {
            background-color: #ffe3e3;  /* pink lembut */
            border: 1px solid #ff9a9a;
        }
        /* Kolom Jumlah */
        .table-pink tbody td:nth-child(3) {
            background-color: #fff7d6;  /* kuning lembut */
            border: 1px solid #ffec99;
        }
        /* Kolom Lokasi */
        .table-pink tbody td:nth-child(4) {
            background-color: #d4f1d4;  /* hijau muda */
            border: 1px solid #8ed88e;
        }
        /* Kolom Kondisi */
        .table-pink tbody td:nth-child(5) {
            background-color: #f5f5f5;  /* abu sangat terang */
            border: 1px solid #ddd;
        }

        /* Button */
        .btn-secondary {
            background-color: #4a90e2;
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            font-size: 1rem;
            border-radius: 25px;
            color: white;
            box-shadow: 0 6px 12px rgba(74, 144, 226, 0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            user-select: none;
            margin-top: 30px;
            display: inline-block;
        }
        .btn-secondary:hover {
            background-color: #2a65c7;
            box-shadow: 0 8px 20px rgba(42, 101, 199, 0.6);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                justify-content: space-around;
                padding: 15px 10px;
            }
            .sidebar h3 {
                margin-bottom: 0;
                font-size: 1.4rem;
            }
            .sidebar a {
                margin-bottom: 0;
                padding: 8px 10px;
                font-size: 0.9rem;
            }
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            .main-content h2 {
                font-size: 1.8rem;
            }
            .main-content h5 {
                font-size: 1rem;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>🛒 Menu</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="inventaris.php">Inventaris Barang</a>
</div>

<div class="main-content">
<img src="img/letter.png" alt="Logo" style="width: 100px; height: auto;">
    <h2>Inventory Kantor</h2>
    <h5>Inventarisasi Barang Aset Kantor</h5>

    <!-- Form Tambah Barang -->
    <form method="POST" class="mb-4">
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="kode_barang" class="form-control" placeholder="Kode Barang" required>
            </div>
            <div class="col">
                <input type="text" name="nama_barang" class="form-control" placeholder="Nama Barang" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="number" name="jumlah" class="form-control" placeholder="Jumlah" required>
            </div>
            <div class="col">
                <input type="text" name="lokasi" class="form-control" placeholder="Lokasi" required>
            </div>
            <div class="col">
                <select name="kondisi" class="form-select" required>
                    <option value="Baik">Baik</option>
                    <option value="Rusak">Rusak</option>
                    <option value="Perbaikan">Perbaikan</option>
                    <option value="Cukup">Cukup</option>
                    <option value="Rusak Ringan">Rusak Ringan</option>
                </select>
            </div>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary">Tambah Barang</button>
    </form>

    <!-- Tabel Data Barang -->
    <table class="table table-bordered text-center table-pink">
        <thead>
            <tr>
                <th><a href="?sort_by=id&order=<?= ($sort_by == 'id' && $order == 'ASC') ? 'DESC' : 'ASC'; ?>">ID</a></th>
                <th><a href="?sort_by=nama_barang&order=<?= ($sort_by == 'nama_barang' && $order == 'ASC') ? 'DESC' : 'ASC'; ?>">Nama Barang</a></th>
                <th><a href="?sort_by=jumlah&order=<?= ($sort_by == 'jumlah' && $order == 'ASC') ? 'DESC' : 'ASC'; ?>">Jumlah</a></th>
                <th><a href="?sort_by=lokasi&order=<?= ($sort_by == 'lokasi' && $order == 'ASC') ? 'DESC' : 'ASC'; ?>">Lokasi</a></th>
                <th><a href="?sort_by=kondisi&order=<?= ($sort_by == 'kondisi' && $order == 'ASC') ? 'DESC' : 'ASC'; ?>">Kondisi</a></th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $data_barang->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['nama_barang']; ?></td>
                <td><?= $row['jumlah']; ?></td>
                <td><?= $row['lokasi']; ?></td>
                <td><?= $row['kondisi']; ?></td>
                <td>
                <a href="?hapus=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                    onclick="return confirm('Yakin ingin menghapus barang ini?')">🗑️</a>
            </tr>
            
            <?php } ?>
        </tbody>
    </table>

    <a href="inventaris.php" class="btn btn-secondary">Refresh</a>
</div>

</body>
</html>
