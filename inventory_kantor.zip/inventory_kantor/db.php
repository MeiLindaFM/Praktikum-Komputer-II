<?php
$host = "localhost";
$user = "root";
$pass = ""; // ganti jika password mysql Anda ada
$db   = "inventory_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
