-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Waktu pembuatan: 06 Jun 2025 pada 17.34
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `kondisi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `jumlah`, `lokasi`, `kondisi`) VALUES
(1, '000000000001', 'Kabel Label 1', 1, 'Vcr/Risak', 'Baik'),
(2, '000000000002', 'TOSHIBA Satellite C40-B-101', 1, 'Vcr/Risak', 'Baik'),
(3, '000000000003', 'Laptop ASUS X441MA', 1, 'Vcr/Risak', 'Baik'),
(4, '000000000004', 'Printer Canon LBP 9130', 1, 'Vcr/Risak', 'Baik'),
(5, '000000000005', 'Printer Canon LBP 2900', 1, 'Vcr/Risak', 'Baik'),
(6, '000000000006', 'Projector BenQ MS527', 1, 'Vcr/Risak', 'Baik'),
(7, '000000000007', 'Projector BenQ MS527', 1, 'Vcr/Risak', 'Baik'),
(8, '000000000008', 'Projector BenQ MS527', 1, 'Vcr/Risak', 'Baik'),
(9, '000000000009', 'Projector BenQ MS527', 1, 'Vcr/Risak', 'Baik'),
(10, '000000000010', 'Laptop ASUS X441MA', 1, 'Vcr/Risak', 'Baik'),
(11, '000000000011', 'Laptop ASUS X441MA', 1, 'Vcr/Risak', 'Baik'),
(12, '000000000012', 'Laptop ASUS X441MA', 1, 'Vcr/Risak', 'Baik'),
(13, '000000000013', 'Meja Kerja TCM/60', 1, 'Vcr/Risak', 'Baik'),
(14, '000000000014', 'Kursi Kerja', 1, 'Vcr/Risak', 'Baik'),
(15, '000000000015', 'Lemari Arsip', 1, 'Vcr/Risak', 'Baik'),
(16, '000000000016', 'Monitor Dell 24 Inch', 1, 'Ruang IT', 'Baik'),
(17, '000000000017', 'Keyboard Logitech K120', 1, 'Gudang', 'Baik'),
(18, '000000000018', 'Mouse Wireless', 1, 'Ruang IT', 'Perbaikan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
