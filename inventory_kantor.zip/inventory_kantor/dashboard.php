<?php
include 'db.php';

// Ambil parameter order_by dan order_dir dari URL
$order_by = isset($_GET['order_by']) ? $_GET['order_by'] : 'id';
$order_dir = isset($_GET['order_dir']) ? $_GET['order_dir'] : 'desc';

// Amankan kolom yang diperbolehkan
$allowed_columns = ['id', 'nama_barang', 'jumlah', 'lokasi', 'kondisi'];
if (!in_array($order_by, $allowed_columns)) {
    $order_by = 'id';
}

// Amankan arah sort
$order_dir = ($order_dir == 'asc') ? 'asc' : 'desc';

// Query dengan ORDER BY dinamis
$data_barang = $conn->query("SELECT * FROM barang ORDER BY $order_by $order_dir");
?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Inventory Kantor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Reset & base */
        body {
            background: linear-gradient(135deg, #c3dfff, #e6f0ff);
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #0a2140;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #4a90e2, #2a65c7);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 30px 20px;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .sidebar h3 {
            margin-bottom: 40px;
            font-weight: 700;
            font-size: 1.8rem;
            letter-spacing: 1.2px;
            user-select: none;
        }
        .sidebar a {
            width: 100%;
            display: block;
            color: #dbe9ff;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: 600;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.3s ease, color 0.3s ease;
            box-shadow: inset 0 0 0 0 transparent;
        }
        .sidebar a:hover {
            background-color: #3b7ddd;
            color: #fff;
            box-shadow: inset 5px 0 10px rgba(255,255,255,0.3);
        }

        /* Main content */
        .main-content {
            margin-left: 260px;
            padding: 40px 50px;
            min-height: 100vh;
        }
        .main-content h2 {
            color: #1a3c72;
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 5px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
        }
        .main-content h5 {
            color: #345c99;
            font-weight: 500;
            margin-bottom: 40px;
            letter-spacing: 0.8px;
        }

        /* Table styles */
        .table-pink thead {
            background-color: #7db9e8; /* soft blue */
            color: #08244f;
            font-weight: 600;
            font-size: 1rem;
        }
        .table-pink tbody tr:nth-child(even) {
            background-color: #d9e9ff;
        }
        .table-pink tbody tr:nth-child(odd) {
            background-color: #f1f9ff;
        }
        .table-pink tbody tr:hover {
            background-color: #a9c9ff;
            color: #08244f;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .table-pink td, .table-pink th {
            vertical-align: middle;
            padding: 14px 18px;
            border-top: none !important;
            border-bottom: 1px solid #c5d9f1;
        }

        /* Kotak warna tiap kolom tbody */
        .table-pink tbody td {
            border-radius: 8px;
            padding: 14px 18px;
            margin: 4px 2px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        /* Kolom ID */
        .table-pink tbody td:nth-child(1) {
            background-color: #d0e7ff;  /* biru muda */
            border: 1px solid #8ab6ff;
        }
        /* Kolom Nama Barang */
        .table-pink tbody td:nth-child(2) {
            background-color: #ffe3e3;  /* pink lembut */
            border: 1px solid #ff9a9a;
        }
        /* Kolom Jumlah */
        .table-pink tbody td:nth-child(3) {
            background-color: #fff7d6;  /* kuning lembut */
            border: 1px solid #ffec99;
        }
        /* Kolom Lokasi */
        .table-pink tbody td:nth-child(4) {
            background-color: #d4f1d4;  /* hijau muda */
            border: 1px solid #8ed88e;
        }
        /* Kolom Kondisi */
        .table-pink tbody td:nth-child(5) {
            background-color: #f5f5f5;  /* abu sangat terang */
            border: 1px solid #ddd;
        }

        /* Button */
        .btn-secondary {
            background-color: #4a90e2;
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            font-size: 1rem;
            border-radius: 25px;
            color: white;
            box-shadow: 0 6px 12px rgba(74, 144, 226, 0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            user-select: none;
            margin-top: 30px;
            display: inline-block;
        }
        .btn-secondary:hover {
            background-color: #2a65c7;
            box-shadow: 0 8px 20px rgba(42, 101, 199, 0.6);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                justify-content: space-around;
                padding: 15px 10px;
            }
            .sidebar h3 {
                margin-bottom: 0;
                font-size: 1.4rem;
            }
            .sidebar a {
                margin-bottom: 0;
                padding: 8px 10px;
                font-size: 0.9rem;
            }
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            .main-content h2 {
                font-size: 1.8rem;
            }
            .main-content h5 {
                font-size: 1rem;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>🛒 Menu</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="index.php">Inventaris Barang</a>
</div>

<div class="main-content">
<img src="img/letter.png" alt="Logo" style="width: 100px; height: auto;">
    <h2>Inventory Kantor</h2>
    <h5>Dashboard Barang Aset Kantor</h5>

    <!-- Tabel Data Barang (read-only) -->
    <table class="table table-bordered text-center table-pink shadow-sm rounded">
        <thead>
            <!-- <tr>
                <th>ID</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Lokasi</th>
                <th>Kondisi</th>
            </tr> -->
            <thead>
            <tr>
                <th>
                    <a href="?order_by=id&order_dir=<?= ($order_by == 'id' && $order_dir == 'asc') ? 'desc' : 'asc'; ?>">ID</a>
                </th>
                <th>
                    <a href="?order_by=nama_barang&order_dir=<?= ($order_by == 'nama_barang' && $order_dir == 'asc') ? 'desc' : 'asc'; ?>">Nama Barang</a>
                </th>
                <th>
                    <a href="?order_by=jumlah&order_dir=<?= ($order_by == 'jumlah' && $order_dir == 'asc') ? 'desc' : 'asc'; ?>">Jumlah</a>
                </th>
                <th>
                    <a href="?order_by=lokasi&order_dir=<?= ($order_by == 'lokasi' && $order_dir == 'asc') ? 'desc' : 'asc'; ?>">Lokasi</a>
                </th>
                <th>
                    <a href="?order_by=kondisi&order_dir=<?= ($order_by == 'kondisi' && $order_dir == 'asc') ? 'desc' : 'asc'; ?>">Kondisi</a>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $data_barang->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['id']); ?></td>
                <td><?= htmlspecialchars($row['nama_barang']); ?></td>
                <td><?= htmlspecialchars($row['jumlah']); ?></td>
                <td><?= htmlspecialchars($row['lokasi']); ?></td>
                <td><?= htmlspecialchars($row['kondisi']); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary">Refresh</a>
</div>

</body>
</html>
